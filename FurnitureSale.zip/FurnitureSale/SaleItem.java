package com.padcmyanmar.oop.FurnitureSale;

public class SaleItem {
    private double quantity;
    private AddFurniture furniture;

    SaleItem(double quantity,AddFurniture furniture){
        this.quantity=quantity;
        this.furniture=furniture;
    }

    public double getQuantity() {
        return quantity;
    }

    public AddFurniture getFurniture() {
        return furniture;
    }
}
