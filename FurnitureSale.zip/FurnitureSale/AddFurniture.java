package com.padcmyanmar.oop.FurnitureSale;

public class AddFurniture {

    private String AddFurnitureName;
    private int AddFurnitureQuantity;
    private String AddFurnitureSaleUnit;
    private double AddFurniturePrice;
    private char AddFurnitureRepresentCharacter;
    private double AddFurnitureDiscountPercent;
    private int AddFurnitureDiscountQuantity;

    public String getAddFurnitureName() {
        return AddFurnitureName;
    }

    public int getAddFurnitureQuantity() {
        return AddFurnitureQuantity;
    }

    public String getAddFurnitureSaleUnit() {
        return AddFurnitureSaleUnit;
    }

    public double getAddFurniturePrice() {
        return AddFurniturePrice;
    }

    public char getAddFurnitureRepresentCharacter() {
        return AddFurnitureRepresentCharacter;
    }

    public double getAddFurnitureDiscountPercent() {
        return AddFurnitureDiscountPercent;
    }

    public int getAddFurnitureDiscountQuantity() {
        return AddFurnitureDiscountQuantity;
    }

    public void setAddFurnitureName(String addFurnitureName) {
        AddFurnitureName = addFurnitureName;
    }

    public void setAddFurnitureQuantity(int addFurnitureQuantity) {
        AddFurnitureQuantity = addFurnitureQuantity;
    }

    public void setAddFurnitureSaleUnit(String addFurnitureSaleUnit) {
        AddFurnitureSaleUnit = addFurnitureSaleUnit;
    }

    public void setAddFurniturePrice(double addFurniturePrice) {
        AddFurniturePrice = addFurniturePrice;
    }

    public void setAddFurnitureRepresentCharacter(char addFurnitureRepresentCharacter) {
        AddFurnitureRepresentCharacter = addFurnitureRepresentCharacter;
    }

    public void setAddFurnitureDiscountPercent(double addFurnitureDiscountPercent) {
        AddFurnitureDiscountPercent = addFurnitureDiscountPercent;
    }

    public void setAddFurnitureDiscountQuantity(int addFurnitureDiscountQuantity) {
        AddFurnitureDiscountQuantity = addFurnitureDiscountQuantity;
    }
}
