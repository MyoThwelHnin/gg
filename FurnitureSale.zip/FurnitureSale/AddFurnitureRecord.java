package com.padcmyanmar.oop.FurnitureSale;

import java.util.ArrayList;

public class AddFurnitureRecord {

    ArrayList<AddFurniture>furnitures=new ArrayList<>();

    public AddFurniture addFurniture(String name,int qty,double price,char key,int dicountQty,double discountPercent){
        furnituresName.add(name);
        furnituresQuantity.add(qty);
        furnituresSalePrice.add(price);
        furnitureRepresentChar.add(key);
        furnittureDiscountEligibleQuantity.add(dicountQty);
        furnitureDiscountPercent.add(discountPercent);

        return addFurniture(name,qty,price,key,dicountQty,discountPercent);
    }
    ArrayList<String>furnituresName=new ArrayList<>();

    ArrayList<Integer>furnituresQuantity=new ArrayList<>();

    ArrayList<String>furnituresSaleUnit=new ArrayList<>();

    ArrayList<Double>furnituresSalePrice=new ArrayList<>();

    ArrayList<Character>furnitureRepresentChar=new ArrayList<>();

    ArrayList<Integer>furnittureDiscountEligibleQuantity=new ArrayList<>();

    ArrayList<Double>furnitureDiscountPercent=new ArrayList<>();

    public ArrayList<String> getFurnituresName() {
        return furnituresName;
    }

    public ArrayList<Integer> getFurnituresQuantity() {
        return furnituresQuantity;
    }

    public ArrayList<String> getFurnituresSaleUnit() {
        return furnituresSaleUnit;
    }

    public ArrayList<Double> getFurnituresSalePrice() {
        return furnituresSalePrice;
    }

    public ArrayList<Character> getFurnitureRepresentChar() {
        return furnitureRepresentChar;
    }

    public ArrayList<Integer> getFurnittureDiscountEligibleQuantity() {
        return furnittureDiscountEligibleQuantity;
    }

    public ArrayList<Double> getFurnitureDiscountPercent() {
        return furnitureDiscountPercent;
    }


}
