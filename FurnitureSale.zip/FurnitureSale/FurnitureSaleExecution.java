package com.padcmyanmar.oop.FurnitureSale;
import java.util.Scanner;

public class FurnitureSaleExecution {

    public static void main(String[]args){

        Scanner input=new Scanner(System.in);

        AddFurnitureRecord furnitureRecord=new AddFurnitureRecord();
        SaleFurniture saleFurniture=new SaleFurniture();

        char userInput;

        System.out.println("====Furniture Sale for Feb 20th====");
        do {

            System.out.print("\n'A' to add new furniture Or 'F' to finish adding furniture: ");
            userInput = input.next().charAt(0);

                System.out.print("\nNew Furniture name: ");
                String addFurnitureName = input.next();
               furnitureRecord.furnituresName.add(addFurnitureName);

                System.out.print("\nSale Quantity: ");
                int addFurnitureQuantity = input.nextInt();
           //     furnitureRecord.furnituresQuantity.add(addFurnitureQuantity);

                System.out.print("\nSale Unit: ");
                String addFurnitureSaleUnit = input.next();
          //      furnitureRecord.furnituresSaleUnit.add(addFurnitureSaleUnit);

                System.out.print("\nSale Price: ");
                double addFrunitureSalePrice = input.nextDouble();
           //     furnitureRecord.furnituresSalePrice.add(addFrunitureSalePrice);

                System.out.print("\nCharacter to represent: ");
                char addFurnitureRepresentChar = input.next().charAt(0);
              furnitureRecord.furnitureRepresentChar.add(addFurnitureRepresentChar);

                System.out.print("\nDiscount Eligible Quantity: ");
                int addFurnitureDiscountEligibleQuantity = input.nextInt();
            //    furnitureRecord.furnittureDiscountEligibleQuantity.add(addFurnitureDiscountEligibleQuantity);

                System.out.print("\nDiscount Percentage: ");
                double addFurnitureDiscountPercent = input.nextDouble();
          //      furnitureRecord.furnitureDiscountPercent.add(addFurnitureDiscountPercent);

                furnitureRecord.addFurniture(addFurnitureName,addFurnitureQuantity,addFrunitureSalePrice,addFurnitureRepresentChar,addFurnitureDiscountEligibleQuantity,addFurnitureDiscountPercent);
                System.out.print("\nNew Furniture named '"+addFurnitureName+"' is saved.");
        }

        while (userInput!='F');

       do {
            System.out.print("\n'S' to start making a new sale and 'D' for show daily summary: ");
            System.out.println("Available Furnitures");
            for (char FurnitureChar:furnitureRecord.getFurnitureRepresentChar()
                 ) {
                for (String FurnitureName:furnitureRecord.getFurnituresName()
                     ) {
                    System.out.println("'"+FurnitureChar+"' for "+FurnitureName);
                }

            }

//sale method call ya mal
           saleFurniture.addSaleItems();
        }
        while (userInput!='D');
    }
}
