package com.padcmyanmar.oop.FurnitureSale;
import java.util.Scanner;
import java.util.ArrayList;

public class SaleFurniture {

    private ArrayList<SaleItem>saleItems;

   public SaleFurniture(){saleItems=new ArrayList<>();}

   public void addSaleItems(){
       Scanner input=new Scanner(System.in);
       char userinput;

       SaleItem newSaleItem;
       AddFurnitureRecord addFurnitureRecord=new AddFurnitureRecord();


       do {
           System.out.print("Please input Furniture Type Or 'E' to finish Sale: ");
           userinput=input.next().charAt(0);

           if (userinput != 'E') {

               System.out.print("How many: ");
               double furnitureQty = input.nextDouble();

           }

       }
       while (userinput!='E');


   }

}
